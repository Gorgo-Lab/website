Sorgenti del progetto.
Ogni cartella ha il suo file di progetto originale.
