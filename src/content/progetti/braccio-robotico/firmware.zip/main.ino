// firmware di esempio
